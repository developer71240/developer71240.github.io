Crop to Opaque - A Photoshop-extending Script

This script for use with Adobe Photoshop® & Adobe Photoshop Elements® will trim an image to remove any transparency. Practical uses are trimming after: merging photos into a panorama, transforming, warping, or rotating.

Tip: undoing the last two history states in photoshop after running the script will result in the opaque area being selected but not trimmed.

See file LICENSE for license

Download: https://developer71240.github.io/crop-to-opaque/

Donate with PayPal*: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=E6EE9WC2Q99RA

* Donations made are NOT tax-deductible.
